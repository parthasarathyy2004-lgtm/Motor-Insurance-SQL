# 🚗 Motor Insurance Management System

A **Motor Insurance Management System** developed using **MySQL** to manage customers, vehicles, insurance policies, premium payments, claims, repairs, employees, and other insurance-related operations. This project demonstrates both basic and advanced MySQL concepts and is suitable for **BCA, B.Sc. Computer Science, MCA, and Diploma Database Management System projects**.

---

## 📌 Project Overview

The Motor Insurance Management System is a relational database project that automates the management of motor insurance records. It provides an organized way to store, retrieve, update, and analyze insurance-related information using SQL.

The system maintains customer records, vehicle information, insurance policies, premium payments, accident reports, claim processing, surveyor inspections, garage repairs, employees, branches, and audit logs. Advanced SQL features are used to improve performance, automate operations, and generate business reports.

---

## 🎯 Project Objectives

- Store customer information securely.
- Manage vehicle registration details.
- Maintain insurance policy records.
- Record premium payment transactions.
- Process insurance claims.
- Manage accident information.
- Track surveyor inspections.
- Maintain garage repair details.
- Manage employee and branch information.
- Generate business reports.
- Demonstrate advanced MySQL concepts.
- Reduce manual paperwork.
- Improve data integrity and consistency.
- Automate database operations using triggers.
- Improve query performance using indexes.

---

## 🛠️ Technologies Used

- **Database:** MySQL 8.0
- **Tool:** MySQL Workbench
- **Language:** SQL

---

## 📂 Database Name

```sql
Motor_Insurance_DB
```

---

## 📊 Database Tables

The project contains **20 tables**.

| No | Table Name |
|----|----------------------|
| 1 | Customer |
| 2 | Agent |
| 3 | Branch |
| 4 | Vehicle_Type |
| 5 | Vehicle |
| 6 | Policy_Type |
| 7 | Insurance_Policy |
| 8 | Premium_Payment |
| 9 | Claim_Status |
|10 | Claim |
|11 | Accident |
|12 | Surveyor |
|13 | Inspection |
|14 | Garage |
|15 | Repair |
|16 | Employee |
|17 | Nominee |
|18 | Document |
|19 | Login |
|20 | Audit_Log |

---

## 📌 Database Features

- Primary Keys
- Foreign Keys
- Constraints
- Auto Increment
- Joins
- Aggregate Functions
- GROUP BY
- HAVING
- ORDER BY
- CASE Statement
- Views
- Indexes
- User Defined Functions
- Stored Procedures
- Triggers
- Transactions
- Business Reports

---

## 📁 Project Structure

```
Motor_Insurance_Management_System/
│
├── Database.sql
├── Tables.sql
├── Insert_Data.sql
├── Business_Queries.sql
├── Views.sql
├── Indexes.sql
├── Functions.sql
├── Procedures.sql
├── Triggers.sql
├── Transactions.sql
├── README.md
└── Documentation.pdf
```

---

## 🔑 SQL Concepts Used

### DDL Commands

- CREATE DATABASE
- CREATE TABLE
- ALTER TABLE
- DROP TABLE

### DML Commands

- INSERT
- UPDATE
- DELETE

### DQL Commands

- SELECT

### TCL Commands

- COMMIT
- ROLLBACK
- SAVEPOINT

### DCL Commands

- GRANT
- REVOKE

---

## 📈 Business Reports

The project generates reports such as:

- Branch Premium Collection
- Top Customers
- Agent Performance
- Vehicle-wise Insurance Report
- Pending Claims
- Employee Salary Report
- Garage Repair Report
- Claim Summary
- Monthly Premium Collection
- Active Policies
- Multiple Policy Customers
- Customer Age Report
- Vehicle Manufacturing Report
- Surveyor Inspection Report
- Policy Expiry Report
- Claim Approval Percentage
- Payment Status Report
- Customer Vehicle Report
- Comprehensive Business Report

---

## ⚡ Advanced MySQL Objects

### Views

- Customer Policy View
- Branch Premium Collection View

### Indexes

- Customer Phone Index
- Policy Status Index

### Functions

- Calculate GST
- Customer Age
- Premium Discount

### Stored Procedures

- Customer Policy Report
- Branch Premium Report
- Claim Report

### Triggers

- Policy Insert Audit Trigger
- Claim Insert Audit Trigger

### Transactions

- Premium Payment Transaction
- Employee Salary Transaction

---

## 🔄 Entity Relationship

```
Customer
    │
    ├── Vehicle
    │      │
    │      ├── Accident
    │      └── Repair
    │
    ├── Insurance Policy
    │      │
    │      ├── Premium Payment
    │      ├── Claim
    │      └── Policy Type
    │
    └── Nominee

Agent ───── Insurance Policy

Branch ──── Agent

Branch ──── Employee

Surveyor ── Inspection ── Claim

Garage ──── Repair
```

---

## 🚀 How to Run

1. Open **MySQL Workbench**.
2. Create a new database.

```sql
CREATE DATABASE Motor_Insurance_DB;
USE Motor_Insurance_DB;
```

3. Execute the table creation script.
4. Insert sample records.
5. Create Views, Functions, Procedures, Triggers, and Indexes.
6. Execute business queries.
7. Verify the outputs.

---

## 📋 Advantages

- Easy to use
- Centralized database
- Secure data management
- Fast query execution
- Automated audit logging
- Improved business reporting
- Reduced data redundancy
- Better customer management
- Efficient claim processing
- Scalable database design

---

## ⚠️ Limitations

- Desktop database only
- Manual data entry
- No online payment integration
- No SMS/Email notification
- No mobile application

---

## 🔮 Future Enhancements

- Online Premium Payment
- Customer Portal
- Mobile Application
- Cloud Database
- Email Notifications
- SMS Alerts
- Aadhaar Verification
- AI-based Fraud Detection
- Dashboard with Charts
- REST API Integration

---

## 📚 Learning Outcomes

This project demonstrates practical knowledge of:

- Relational Database Design
- SQL Programming
- Data Normalization
- Database Relationships
- Aggregate Functions
- Joins
- Views
- Indexing
- User Defined Functions
- Stored Procedures
- Triggers
- Transactions
- Business Intelligence Queries

---

## 👨‍💻 Author

**Sathish M**

Bachelor of Computer Applications (BCA)

Database Management System Project

Academic Year: 2026

---

## 📄 License

This project is created for **educational and academic purposes**. Feel free to use and modify it for learning and research.